import socket
from _thread import *
import pandas as pd
import datetime
import random
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
ThreadCount = 0
try:
    s.bind((socket.gethostname(), 2000))
except socket.error as e:
    print(str(e))
print('Waiting for a Connection..')
s.listen(5)


def threaded_client(clt):
    while True:
        df = pd.read_csv(r"C:\Users\SNEHA\Downloads\network\archive\train_info.csv")
        df1 = pd.read_csv(r"C:\Users\SNEHA\Downloads\network\archive\train_schedule2 edited.csv")
        df4 = pd.read_csv(r"C:\Users\SNEHA\Downloads\network\archive\bank_details.csv")
        df6 = pd.read_csv(r"C:\Users\SNEHA\Downloads\network\archive\waiting_list.csv")
        df5 = pd.read_csv(r"C:\Users\SNEHA\Downloads\network\archive\Passenger_info.csv")
        ch = clt.recv(100).decode("utf-8")
        if ch == 'Booking':
            clt.send(bytes("server.csv", "utf-8"))
            source = clt.recv(1000).decode("utf-8")
            destination = clt.recv(1000).decode("utf-8")
            d2 = df.loc[(df['Source_Station_Name'] == source) & (df['Destination_Station_Name'] == destination)]
            d2.to_csv('info.csv', index=False)
            clt.send(bytes("info.csv", "utf-8"))
            train_no = clt.recv(1000).decode("utf-8")
            coach = clt.recv(50).decode("utf-8")
            no_of_ticket = clt.recv(1000).decode("utf-8")
            if coach == 'Sleeper':
                a = df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))][
                    'price_sleeper'].values
            elif coach == '2 - tier':
                a = df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))]['Price_2-tier'].values
            elif coach == '3 - tier':
                a = df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))]['Price_3-tier'].values
            else:
                a = df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))][
                    'price_general'].values
            station_code = \
                df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))][
                    'Station_Code'].values
            arrival_time = \
                df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))][
                    'Arrival_time'].values
            departure_Time = \
                df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))][
                    'Departure_Time'].values
            dept_Date = df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))][
                'departure_DATE'].values
            arrival_date = df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))][
                'arrival_DATE'].values
            day = df.loc[
                (df['Source_Station_Name'] == source) & (df['Train_No'] == int(train_no)) & (
                        df['Destination_Station_Name'] == destination)]['days'].values
            train_name = df.loc[
                (df['Source_Station_Name'] == source) & (df['Train_No'] == int(train_no)) & (
                        df['Destination_Station_Name'] == destination)]['Train_Name'].values
            station_code = str(station_code).lstrip('\'[').rstrip('\']')
            arrival_time = str(arrival_time).lstrip('\'[').rstrip('\']')
            departure_Time = str(departure_Time).lstrip('\'[').rstrip('\']')
            day = str(day).lstrip('\'[').rstrip('\']')
            train_name = str(train_name).lstrip('\'[').rstrip('\']')
            dept_Date = str(dept_Date).lstrip('\'[').rstrip('\']')
            arrival_date = str(arrival_date).lstrip('\'[').rstrip('\']')
            d = df1.loc[(df1['Station_Name'] == source) & (df1['Train_No'] == int(train_no))][coach].values
            dt = datetime.date.today()
            diff = d - int(no_of_ticket)
            diff = str(diff).lstrip('[').rstrip(']')
            diff = int(diff)
            PNR = random.randint(100000, 999999)
            number = random.randint(1000, 9999)
            if diff >= 0:
                clt.send(bytes("Seats Available", "utf-8"))

                tot_amount = a * int(no_of_ticket)
                t = str(tot_amount).lstrip('[').rstrip('.]')
                clt.send(bytes("Total amount:", "utf-8"))
                clt.send(t.encode("utf-8"))

                list1 = [[int(train_no), source, station_code, destination, arrival_time, departure_Time, day, coach,
                          int(no_of_ticket), float(t), train_name, dt, PNR, number, dept_Date, arrival_date]]

                df5 = pd.DataFrame(list1,
                                   columns=['TRAIN NO', 'STATION NAME', 'STATION CODE', 'DESTINATION', 'ARRIVAL TIME',
                                            'DEPARTURE TIME', 'DAY', 'COACH', 'NO OF TICKETS', 'AMOUNT', 'TRAIN NAME',
                                            'DATE_TIME', 'PNR NUMBER', 'booking id', 'departure_DATE', 'arrival_DATE'])

                df5.to_csv("C:/Users/SNEHA/Downloads/network/archive/Passenger_info.csv", mode='a', header=False,
                           index=False)

                clt.send(str(number).encode("utf-8"))
            else:
                clt.send(bytes("No of seats available are: ", "utf-8"))
                x = int(no_of_ticket) + diff
                clt.send(str(x).encode("utf-8"))

                z = clt.recv(1000).decode("utf-8")
                if z == 'yes':
                    clt.send(bytes("yes", "utf-8"))
                    tot_amount = a * x
                    t = str(tot_amount).lstrip('[').rstrip('.]')
                    clt.send(bytes("Total amount:", "utf-8"))
                    clt.send(t.encode("utf-8"))
                    list1 = [
                        [int(train_no), source, station_code, destination, arrival_time, departure_Time, day, coach,
                         x, float(t), train_name, dt, PNR, number, dept_Date, arrival_date]]

                    df5 = pd.DataFrame(list1,
                                       columns=['TRAIN NO', 'STATION NAME', 'STATION CODE', 'DESTINATION',
                                                'ARRIVAL TIME',
                                                'DEPARTURE TIME', 'DAY', 'COACH', 'NO OF TICKETS', 'AMOUNT',
                                                'TRAIN NAME',
                                                'DATE_TIME', 'PNR NUMBER', 'booking id', 'departure_DATE',
                                                'arrival_DATE'])

                    df5.to_csv("C:/Users/SNEHA/Downloads/network/archive/Passenger_info.csv", mode='a',
                               header=False, index=False)

                    tot_amount1 = a * abs(diff)
                    t1 = str(tot_amount1).lstrip('[').rstrip('.]')

                    list2 = [
                        [int(train_no), source, station_code, destination, arrival_time, departure_Time, day, coach,
                         abs(diff), abs(float(t1)), train_name, dt, PNR, number, dept_Date, arrival_date]]

                    df6 = pd.DataFrame(list2, columns=['TRAIN NO', 'STATION NAME', 'STATION CODE', 'DESTINATION',
                                                       'ARRIVAL TIME', 'DEPARTURE TIME', 'DAY', 'COACH',
                                                       'NO OF TICKETS', 'AMOUNT', 'TRAIN NAME', 'DATE_TIME',
                                                       'PNR NUMBER', 'booking id', 'departure_DATE', 'arrival_DATE'])

                    df6.to_csv("C:/Users/SNEHA/Downloads/network/archive/waiting_list.csv", mode='a',
                               header=False, index=False)

                    clt.send(bytes(
                        "Unavailable tickets are enter into waiting list \nwaiting for payment for available "
                        "tickets\nYour booking id",
                        "utf-8"))
                    clt.send(str(number).encode("utf-8"))
                else:
                    clt.send(bytes("No", "utf-8"))
                    tot_amount = a * int(no_of_ticket)
                    t = str(tot_amount).lstrip('[').rstrip('.]')
                    list1 = [
                        [int(train_no), source, station_code, destination, arrival_time, departure_Time, day, coach,
                         int(no_of_ticket), float(t), train_name, dt, PNR, number, dept_Date, arrival_date]]

                    df6 = pd.DataFrame(list1, columns=['TRAIN NO', 'STATION NAME', 'STATION CODE', 'DESTINATION',
                                                       'ARRIVAL TIME', 'DEPARTURE TIME', 'DAY', 'COACH',
                                                       'NO OF TICKETS', 'AMOUNT', 'TRAIN NAME', 'DATE_TIME',
                                                       'PNR NUMBER', 'booking id', 'departure_DATE', 'arrival_DATE'])

                    df6.to_csv("C:/Users/SNEHA/Downloads/network/archive/waiting_list.csv", mode='a',
                               header=False, index=False)
                    clt.send(bytes("Ticket entered in waiting list", "utf-8"))

        elif ch == 'Cancellation':
            clt.send(bytes("Enter the PNR NUMBER: ", "utf-8"))
            pnr_no = clt.recv(1000).decode("utf-8")
            pnr_no = int(pnr_no)
            if pnr_no in df5.values:
                clt.send(bytes("Cancel ticket", "utf-8"))
                if clt.recv(1000).decode("utf-8") == 'yes':
                    clt.send(bytes("yes", "utf-8"))
                    no_ticket = df5.loc[(df5['PNR NUMBER'] == pnr_no)]['NO OF TICKETS'].values
                    CLASS = df5.loc[(df5['PNR NUMBER'] == pnr_no)]['COACH'].values
                    price = df5.loc[(df5['PNR NUMBER'] == pnr_no)]['AMOUNT'].values
                    train = df5.loc[(df5['PNR NUMBER'] == pnr_no)]['TRAIN NO'].values
                    source_c = df5.loc[(df5['PNR NUMBER'] == pnr_no)]['STATION NAME'].values

                    source_c = str(source_c).lstrip('\'[').rstrip('\']')
                    train = str(train).lstrip('\'[').rstrip('\']')
                    price = str(price).lstrip('\'[').rstrip('.\']')
                    no_ticket = str(no_ticket).lstrip('\'[').rstrip('\']')
                    CLASS = str(CLASS).lstrip('\'[').rstrip('\']')

                    price = float(price)
                    tot_price = price * 0.95

                    df5.loc[(df5['PNR NUMBER'] == pnr_no), 'AMOUNT'] = float(tot_price)
                    df5.loc[(df5['PNR NUMBER'] == pnr_no), 'Cancelled'] = 'yes'
                    df5.to_csv("C:/Users/SNEHA/Downloads/network/archive/Passenger_info.csv", mode='w', index=False)

                    d = df1.loc[(df1['Station_Name'] == source_c) & (df1['Train_No'] == int(train))][
                        CLASS].values

                    d = str(d).lstrip('\'[').rstrip('.\']')
                    df1.loc[(df1['Station_Name'] == source_c) & (df1['Train_No'] == int(train)), CLASS] = int(d) + int(
                        no_ticket)

                    df1.to_csv("C:/Users/SNEHA/Downloads/network/archive/train_schedule2 edited.csv", mode='w',
                               index=False)

                    clt.send(bytes("Ticket cancellation successful", "utf-8"))
                else:
                    clt.send(bytes("no", "utf-8"))
            else:
                clt.send(bytes("Invalid PNR NUMBER", "utf-8"))
        elif ch == 'VIEW':
            clt.send(bytes("C:/Users/SNEHA/Downloads/network/archive/Passenger_info.csv", "utf-8"))
    clt.close()
while True:
    client, adr = s.accept()
    print(f"Connection established to {adr} established")
    start_new_thread(threaded_client, (client,))
    ThreadCount += 1
    print('Thread Number: ' + str(ThreadCount))

s.close()

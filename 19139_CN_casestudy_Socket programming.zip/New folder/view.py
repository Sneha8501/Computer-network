import socket
import pandas as pd
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print('Waiting for connection')
try:
    s.connect((socket.gethostname(), 2000))
except socket.error as e:
    print(str(e))
s.send(bytes("VIEW", "utf-8"))
file = s.recv(1000).decode("utf-8")
pnr = int(input("Enter PNR number: "))
df = pd.read_csv(file)
x = df.loc[df['PNR NUMBER'] == pnr]
info = x[['PNR NUMBER','NAME', 'PHONE NO', 'TRAIN NO', 'STATION NAME', 'STATION CODE', 'DESTINATION', 'ARRIVAL TIME','DEPARTURE TIME','DAY', 'COACH', 'NO OF TICKETS', 'AMOUNT', 'TRAIN NAME', 'DATE_TIME', 'departure_DATE', 'arrival_DATE']]
info.set_index('PNR NUMBER', inplace=True)
print(info.head())
s.close()

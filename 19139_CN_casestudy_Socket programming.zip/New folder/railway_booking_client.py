import socket
import pandas as pd
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print('Waiting for connection')
try:
    s.connect((socket.gethostname(), 2000))
except socket.error as e:
    print(str(e))
df = pd.read_csv(r"C:\Users\SNEHA\Downloads\network\archive\train_schedule2 edited.csv")
s.send(bytes("Booking", "utf-8"))
msg = s.recv(665285).decode("utf-8")
print(pd.read_csv(msg))
source = input("Enter source: ")
s.send(source.encode("utf-8"))
destination = input("Enter destination: ")
s.send(destination.encode("utf-8"))
print(pd.read_csv(s.recv(665285).decode("utf-8")))
train_no = int(input("Enter the train number: "))
s.send(str(train_no).encode("utf-8"))
d = df.loc[(df['Station_Name'] == source) & (df['Train_No'] == train_no)]
print(d)
coach = input("Enter coach number: ")
s.send(coach.encode("utf-8"))
no_ticket = int(input("Enter number of ticket: "))
s.send(str(no_ticket).encode("utf-8"))
msg2 = s.recv(1000).decode("utf-8")
if msg2 == 'Seats Available':
    print(s.recv(1000).decode("utf-8"), end=' ')
    print(s.recv(1000).decode("utf-8"))
    print("waiting for payment\nYour booking id is:")
    print(s.recv(1000).decode("utf-8"))

else:
    print(msg2, end=' ')
    print(s.recv(2000).decode("utf-8"))
    choice = input("Proceed with booking the tickets available\nyes or no??: ")
    s.send(choice.encode("utf-8"))
    m = s.recv(1000).decode("utf-8")
    if m == 'yes':
        print(s.recv(1000).decode("utf-8"))
        print(s.recv(1000).decode("utf-8"))
        print(s.recv(1000).decode("utf-8"))
        print(s.recv(1000).decode("utf-8"))
    else:
        print(s.recv(1000).decode("utf-8"))

s.close()



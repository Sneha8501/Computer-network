import socket
import pandas as pd
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print('Waiting for connection')
try:
    s.connect((socket.gethostname(), 2000))
except socket.error as e:
    print(str(e))

df = pd.read_csv(r"C:\Users\SNEHA\Downloads\network\archive\train_schedule2 edited.csv")
s.send(bytes("Cancellation", "utf-8"))
pnr = int(input(s.recv(665285).decode("utf-8")))
s.send(str(pnr).encode("utf-8"))
msg9 = s.recv(1000).decode("utf-8")
if msg9 == 'Cancel ticket':
    c1 = input("Cancel ticket??\nyes or no: ")
    s.send(c1.encode("utf-8"))
    msg1 = s.recv(1000).decode("utf-8")
    if msg1 == 'yes':
        print(s.recv(1000).decode("utf-8"))
    else:
        exit()
else:
    print(msg9)
    exit()
s.close()


